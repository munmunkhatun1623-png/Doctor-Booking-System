// Demonstrates inline-style based styling (as opposed to CSS Modules/styled-components
// used elsewhere), driven entirely by props.
export default function Rating({ value, reviews }) {
  const containerStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    fontSize: '0.85rem',
    fontWeight: 600,
    color: '#b7791f'
  }

  const starStyle = {
    color: '#f5a524',
    fontSize: '0.95rem'
  }

  return (
    <span style={containerStyle}>
      <span style={starStyle}>★</span>
      {value.toFixed(1)}
      {reviews != null && (
        <span style={{ color: 'var(--color-text-muted)', fontWeight: 500 }}>
          ({reviews} reviews)
        </span>
      )}
    </span>
  )
}
