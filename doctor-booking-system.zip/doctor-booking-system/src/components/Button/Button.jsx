import styled, { css } from 'styled-components'

const variantStyles = {
  primary: css`
    background: var(--color-primary);
    color: #fff;
    &:hover:not(:disabled) {
      background: var(--color-primary-dark);
    }
  `,
  outline: css`
    background: transparent;
    color: var(--color-primary);
    border: 1px solid var(--color-primary);
    &:hover:not(:disabled) {
      background: #eef4fb;
    }
  `,
  danger: css`
    background: transparent;
    color: var(--color-danger);
    border: 1px solid var(--color-danger);
    &:hover:not(:disabled) {
      background: #fdeeee;
    }
  `
}

const StyledButton = styled.button`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: ${(props) => (props.$size === 'sm' ? '8px 14px' : '11px 20px')};
  font-size: ${(props) => (props.$size === 'sm' ? '0.85rem' : '0.95rem')};
  font-weight: 600;
  border: none;
  border-radius: var(--radius-sm);
  cursor: pointer;
  transition: background 0.15s ease, opacity 0.15s ease;
  width: ${(props) => (props.$fullWidth ? '100%' : 'auto')};

  &:disabled {
    opacity: 0.55;
    cursor: not-allowed;
  }

  ${(props) => variantStyles[props.$variant] || variantStyles.primary}
`

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  ...rest
}) {
  return (
    <StyledButton $variant={variant} $size={size} $fullWidth={fullWidth} {...rest}>
      {children}
    </StyledButton>
  )
}
