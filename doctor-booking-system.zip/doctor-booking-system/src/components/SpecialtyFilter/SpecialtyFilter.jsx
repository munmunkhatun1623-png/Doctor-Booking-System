export default function SpecialtyFilter({ specialties, value, onChange }) {
  return (
    <select
      className="form-input"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{ maxWidth: 220 }}
    >
      <option value="">All Specialties</option>
      {specialties.map((s) => (
        <option key={s} value={s}>
          {s}
        </option>
      ))}
    </select>
  )
}
