import styles from './Loader.module.css'

export default function Loader({ label = 'Loading...' }) {
  return (
    <div className={styles.wrapper}>
      <div className={styles.spinner} />
      <p className={styles.label}>{label}</p>
    </div>
  )
}
