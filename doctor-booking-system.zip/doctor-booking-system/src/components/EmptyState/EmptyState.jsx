export default function EmptyState({ title, subtitle, action }) {
  return (
    <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--color-text-muted)' }}>
      <h3 style={{ margin: '0 0 6px', color: 'var(--color-text)' }}>{title}</h3>
      {subtitle && <p style={{ margin: '0 0 16px' }}>{subtitle}</p>}
      {action}
    </div>
  )
}
