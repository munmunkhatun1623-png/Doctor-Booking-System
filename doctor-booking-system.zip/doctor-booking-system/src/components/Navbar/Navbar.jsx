import { NavLink } from 'react-router-dom'
import styles from './Navbar.module.css'

export default function Navbar() {
  return (
    <header className={styles.navbar}>
      <div className={styles.inner}>
        <NavLink to="/" className={styles.logo}>
          <span className={styles.logoMark}>+</span> MediBook
        </NavLink>
        <nav className={styles.links}>
          <NavLink
            to="/"
            end
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
          >
            Find Doctors
          </NavLink>
          <NavLink
            to="/appointments"
            className={({ isActive }) => (isActive ? styles.activeLink : styles.link)}
          >
            My Appointments
          </NavLink>
        </nav>
      </div>
    </header>
  )
}
