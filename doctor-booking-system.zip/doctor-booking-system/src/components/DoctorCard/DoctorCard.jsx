import { useNavigate } from 'react-router-dom'
import Rating from '../Rating/Rating.jsx'
import Button from '../Button/Button.jsx'
import styles from './DoctorCard.module.css'

export default function DoctorCard({ doctor }) {
  const navigate = useNavigate()

  return (
    <div className={styles.card}>
      <img src={doctor.photo} alt={doctor.name} className={styles.photo} />
      <div className={styles.body}>
        <div className={styles.headerRow}>
          <h3 className={styles.name}>{doctor.name}</h3>
          <Rating value={doctor.rating} />
        </div>
        <p className={styles.specialty}>{doctor.specialty}</p>
        <p className={styles.meta}>
          {doctor.experience}+ yrs experience &middot; {doctor.location}
        </p>
        <div className={styles.footerRow}>
          <span className={styles.fee}>₹{doctor.fee} fee</span>
          <div className={styles.actions}>
            <Button variant="outline" size="sm" onClick={() => navigate(`/doctors/${doctor.id}`)}>
              View Profile
            </Button>
            <Button size="sm" onClick={() => navigate(`/book/${doctor.id}`)}>
              Book Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
