// Simulated backend. Every function returns a Promise and has an artificial
// network delay + occasional simulated failure, so the UI can demonstrate
// real loading / error / success states exactly like it would against a
// real REST API. Booked slots are persisted in localStorage so availability
// updates "live" as soon as a booking is made, without a page refresh.

import { doctors as SEED_DOCTORS } from '../data/doctors.js'

const LATENCY = 500
const BOOKINGS_KEY = 'medibook_appointments'

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function readBookings() {
  try {
    return JSON.parse(localStorage.getItem(BOOKINGS_KEY)) || []
  } catch {
    return []
  }
}

function writeBookings(bookings) {
  localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings))
}

function isSlotBooked(bookings, doctorId, date, time) {
  return bookings.some(
    (b) => b.doctorId === doctorId && b.date === date && b.time === time && b.status !== 'cancelled'
  )
}

/** GET /doctors — optionally filtered by search text + specialty */
export async function fetchDoctors({ search = '', specialty = '' } = {}) {
  await delay(LATENCY)
  let result = SEED_DOCTORS
  if (specialty) {
    result = result.filter((d) => d.specialty === specialty)
  }
  if (search.trim()) {
    const q = search.trim().toLowerCase()
    result = result.filter(
      (d) => d.name.toLowerCase().includes(q) || d.specialty.toLowerCase().includes(q)
    )
  }
  return result
}

/** GET /doctors/:id */
export async function fetchDoctorById(id) {
  await delay(LATENCY)
  const doc = SEED_DOCTORS.find((d) => d.id === id)
  if (!doc) throw new Error('Doctor not found')
  return doc
}

/** GET /doctors/:id/availability?date=YYYY-MM-DD — live slots minus already-booked ones */
export async function fetchAvailability(doctorId, date) {
  await delay(350)
  const doc = SEED_DOCTORS.find((d) => d.id === doctorId)
  if (!doc) throw new Error('Doctor not found')
  const allSlots = doc.availability[date] || []
  const bookings = readBookings()
  return allSlots.map((time) => ({
    time,
    booked: isSlotBooked(bookings, doctorId, date, time)
  }))
}

/** POST /appointments */
export async function bookAppointment({ doctorId, date, time, patient }) {
  await delay(700)
  const bookings = readBookings()

  if (isSlotBooked(bookings, doctorId, date, time)) {
    const err = new Error('This slot was just booked by someone else. Please pick another.')
    err.code = 'SLOT_TAKEN'
    throw err
  }

  const doc = SEED_DOCTORS.find((d) => d.id === doctorId)
  const appointment = {
    id: `appt-${Date.now()}`,
    doctorId,
    doctorName: doc?.name ?? 'Unknown',
    specialty: doc?.specialty ?? '',
    date,
    time,
    patient,
    status: 'confirmed',
    createdAt: new Date().toISOString()
  }

  bookings.push(appointment)
  writeBookings(bookings)
  return appointment
}

/** GET /appointments */
export async function fetchAppointments() {
  await delay(300)
  return readBookings().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
}

/** DELETE /appointments/:id */
export async function cancelAppointment(appointmentId) {
  await delay(400)
  const bookings = readBookings()
  const updated = bookings.map((b) =>
    b.id === appointmentId ? { ...b, status: 'cancelled' } : b
  )
  writeBookings(updated)
  return true
}
