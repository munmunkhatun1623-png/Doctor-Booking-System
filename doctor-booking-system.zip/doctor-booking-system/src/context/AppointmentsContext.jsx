import { createContext, useContext, useReducer, useCallback, useMemo } from 'react'
import { fetchAppointments, bookAppointment, cancelAppointment } from '../api/doctorsApi.js'

const AppointmentsContext = createContext(null)

const initialState = {
  items: [],
  loading: false,
  error: null
}

function reducer(state, action) {
  switch (action.type) {
    case 'FETCH_START':
      return { ...state, loading: true, error: null }
    case 'FETCH_SUCCESS':
      return { ...state, loading: false, items: action.payload }
    case 'FETCH_ERROR':
      return { ...state, loading: false, error: action.payload }
    case 'ADD_APPOINTMENT':
      return { ...state, items: [action.payload, ...state.items] }
    case 'CANCEL_APPOINTMENT':
      return {
        ...state,
        items: state.items.map((a) =>
          a.id === action.payload ? { ...a, status: 'cancelled' } : a
        )
      }
    default:
      return state
  }
}

export function AppointmentsProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState)

  const loadAppointments = useCallback(async () => {
    dispatch({ type: 'FETCH_START' })
    try {
      const data = await fetchAppointments()
      dispatch({ type: 'FETCH_SUCCESS', payload: data })
    } catch (err) {
      dispatch({ type: 'FETCH_ERROR', payload: err.message })
    }
  }, [])

  const addAppointment = useCallback(async (payload) => {
    const appointment = await bookAppointment(payload)
    dispatch({ type: 'ADD_APPOINTMENT', payload: appointment })
    return appointment
  }, [])

  const removeAppointment = useCallback(async (id) => {
    await cancelAppointment(id)
    dispatch({ type: 'CANCEL_APPOINTMENT', payload: id })
  }, [])

  const value = useMemo(
    () => ({
      appointments: state.items,
      loading: state.loading,
      error: state.error,
      loadAppointments,
      addAppointment,
      removeAppointment
    }),
    [state, loadAppointments, addAppointment, removeAppointment]
  )

  return (
    <AppointmentsContext.Provider value={value}>
      {children}
    </AppointmentsContext.Provider>
  )
}

export function useAppointments() {
  const ctx = useContext(AppointmentsContext)
  if (!ctx) throw new Error('useAppointments must be used within AppointmentsProvider')
  return ctx
}
