import { useEffect, useRef, useState, useCallback } from 'react'

/**
 * Generic async-data hook: runs `fetcher`, tracks loading/error/data,
 * and re-runs whenever `deps` change. Guards against setting state
 * after unmount (fast route changes) so it's safe for real-time-ish
 * screens like availability checking.
 */
export function useFetch(fetcher, deps = []) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const mountedRef = useRef(true)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const result = await fetcher()
      if (mountedRef.current) setData(result)
    } catch (err) {
      if (mountedRef.current) setError(err.message || 'Something went wrong')
    } finally {
      if (mountedRef.current) setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  useEffect(() => {
    mountedRef.current = true
    load()
    return () => {
      mountedRef.current = false
    }
  }, [load])

  return { data, loading, error, refetch: load }
}
