import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar/Navbar.jsx'
import Home from './pages/Home/Home.jsx'
import DoctorDetails from './pages/DoctorDetails/DoctorDetails.jsx'
import BookAppointment from './pages/BookAppointment/BookAppointment.jsx'
import MyAppointments from './pages/MyAppointments/MyAppointments.jsx'
import NotFound from './pages/NotFound/NotFound.jsx'

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/doctors/:id" element={<DoctorDetails />} />
        <Route path="/book/:id" element={<BookAppointment />} />
        <Route path="/appointments" element={<MyAppointments />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  )
}
