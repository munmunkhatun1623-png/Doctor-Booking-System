import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useFetch } from '../../hooks/useFetch.js'
import { fetchDoctorById, fetchAvailability } from '../../api/doctorsApi.js'
import { useAppointments } from '../../context/AppointmentsContext.jsx'
import Loader from '../../components/Loader/Loader.jsx'
import Button from '../../components/Button/Button.jsx'
import EmptyState from '../../components/EmptyState/EmptyState.jsx'
import styles from './BookAppointment.module.css'

export default function BookAppointment() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { addAppointment } = useAppointments()

  const { data: doctor, loading: loadingDoctor } = useFetch(() => fetchDoctorById(id), [id])

  const dates = doctor ? Object.keys(doctor.availability).slice(0, 6) : []
  const [selectedDate, setSelectedDate] = useState(null)
  const [selectedTime, setSelectedTime] = useState(null)
  const [form, setForm] = useState({ name: '', age: '', phone: '', reason: '' })
  const [formErrors, setFormErrors] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState(null)
  const [confirmed, setConfirmed] = useState(null)

  // Live availability for the selected date — re-fetched from the mock API
  // each time the date changes, reflecting real bookings already made.
  const {
    data: slots,
    loading: loadingSlots,
    error: slotsError,
    refetch: refetchSlots
  } = useFetch(
    () => (selectedDate ? fetchAvailability(id, selectedDate) : Promise.resolve(null)),
    [id, selectedDate]
  )

  function handleDateSelect(date) {
    setSelectedDate(date)
    setSelectedTime(null)
  }

  function handleFieldChange(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }))
    setFormErrors((prev) => ({ ...prev, [field]: null }))
  }

  function validate() {
    const errors = {}
    if (!form.name.trim()) errors.name = 'Full name is required'
    if (!form.age || Number(form.age) <= 0) errors.age = 'Enter a valid age'
    if (!/^\d{10}$/.test(form.phone)) errors.phone = 'Enter a 10-digit phone number'
    if (!selectedDate || !selectedTime) errors.slot = 'Please select a date and time'
    setFormErrors(errors)
    return Object.keys(errors).length === 0
  }

  async function handleSubmit(e) {
    e.preventDefault()
    if (!validate()) return

    setSubmitting(true)
    setSubmitError(null)
    try {
      const appointment = await addAppointment({
        doctorId: id,
        date: selectedDate,
        time: selectedTime,
        patient: { ...form }
      })
      setConfirmed(appointment)
    } catch (err) {
      setSubmitError(err.message)
      if (err.code === 'SLOT_TAKEN') {
        setSelectedTime(null)
        refetchSlots()
      }
    } finally {
      setSubmitting(false)
    }
  }

  if (loadingDoctor) return <Loader label="Loading booking page..." />
  if (!doctor) {
    return (
      <div className="page-container">
        <EmptyState title="Doctor not found" />
      </div>
    )
  }

  if (confirmed) {
    return (
      <div className="page-container">
        <div className={styles.confirmCard}>
          <div className={styles.confirmIcon}>✓</div>
          <h2>Appointment Confirmed!</h2>
          <p className={styles.confirmDetail}>
            {doctor.name} &middot; {new Date(confirmed.date).toLocaleDateString(undefined, {
              weekday: 'long',
              month: 'long',
              day: 'numeric'
            })} at {confirmed.time}
          </p>
          <p className={styles.confirmId}>Confirmation ID: {confirmed.id}</p>
          <div className={styles.confirmActions}>
            <Button onClick={() => navigate('/appointments')}>View My Appointments</Button>
            <Button variant="outline" onClick={() => navigate('/')}>Back to Home</Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="page-container">
      <h1 className="page-heading">Book an Appointment</h1>
      <p className="page-subheading">with {doctor.name} &middot; {doctor.specialty}</p>

      <form onSubmit={handleSubmit} className={styles.layout}>
        <div className={styles.slotPanel}>
          <h3 className={styles.panelTitle}>1. Select a date</h3>
          <div className={styles.dateRow}>
            {dates.map((date) => (
              <button
                type="button"
                key={date}
                className={`${styles.dateChip} ${selectedDate === date ? styles.dateChipActive : ''}`}
                onClick={() => handleDateSelect(date)}
              >
                {new Date(date).toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' })}
              </button>
            ))}
          </div>

          <h3 className={styles.panelTitle}>2. Select a time slot</h3>
          {!selectedDate && (
            <p className={styles.hint}>Pick a date to see available times.</p>
          )}
          {selectedDate && loadingSlots && <Loader label="Checking live availability..." />}
          {selectedDate && slotsError && <p className="form-error">{slotsError}</p>}
          {selectedDate && slots && (
            <div className={styles.slotGrid}>
              {slots.map(({ time, booked }) => (
                <button
                  type="button"
                  key={time}
                  disabled={booked}
                  className={`${styles.slotChip} ${selectedTime === time ? styles.slotChipActive : ''} ${booked ? styles.slotChipBooked : ''}`}
                  onClick={() => setSelectedTime(time)}
                  title={booked ? 'Already booked' : `Book ${time}`}
                >
                  {time}
                </button>
              ))}
            </div>
          )}
          {formErrors.slot && <p className="form-error">{formErrors.slot}</p>}
        </div>

        <div className={styles.formPanel}>
          <h3 className={styles.panelTitle}>3. Patient details</h3>

          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input
              className="form-input"
              value={form.name}
              onChange={(e) => handleFieldChange('name', e.target.value)}
              placeholder="e.g. Riya Sen"
            />
            {formErrors.name && <p className="form-error">{formErrors.name}</p>}
          </div>

          <div className="form-group">
            <label className="form-label">Age</label>
            <input
              type="number"
              className="form-input"
              value={form.age}
              onChange={(e) => handleFieldChange('age', e.target.value)}
              placeholder="e.g. 29"
            />
            {formErrors.age && <p className="form-error">{formErrors.age}</p>}
          </div>

          <div className="form-group">
            <label className="form-label">Phone Number</label>
            <input
              className="form-input"
              value={form.phone}
              onChange={(e) => handleFieldChange('phone', e.target.value)}
              placeholder="10-digit mobile number"
            />
            {formErrors.phone && <p className="form-error">{formErrors.phone}</p>}
          </div>

          <div className="form-group">
            <label className="form-label">Reason for visit (optional)</label>
            <textarea
              className="form-input"
              rows={3}
              value={form.reason}
              onChange={(e) => handleFieldChange('reason', e.target.value)}
              placeholder="Briefly describe your symptoms or reason"
            />
          </div>

          {submitError && <p className="form-error">{submitError}</p>}

          <Button type="submit" fullWidth disabled={submitting}>
            {submitting ? 'Booking...' : `Confirm Booking (₹${doctor.fee})`}
          </Button>
        </div>
      </form>
    </div>
  )
}
