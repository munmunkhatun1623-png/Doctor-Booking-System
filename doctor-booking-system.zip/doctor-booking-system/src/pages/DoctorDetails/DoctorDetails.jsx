import { useParams, useNavigate, Link } from 'react-router-dom'
import { useFetch } from '../../hooks/useFetch.js'
import { fetchDoctorById } from '../../api/doctorsApi.js'
import Loader from '../../components/Loader/Loader.jsx'
import Rating from '../../components/Rating/Rating.jsx'
import Button from '../../components/Button/Button.jsx'
import EmptyState from '../../components/EmptyState/EmptyState.jsx'
import styles from './DoctorDetails.module.css'

export default function DoctorDetails() {
  const { id } = useParams()
  const navigate = useNavigate()

  const { data: doctor, loading, error } = useFetch(() => fetchDoctorById(id), [id])

  if (loading) return <Loader label="Loading doctor profile..." />

  if (error || !doctor) {
    return (
      <div className="page-container">
        <EmptyState
          title="Doctor not found"
          subtitle={error}
          action={<Link to="/"><Button variant="outline">Back to search</Button></Link>}
        />
      </div>
    )
  }

  const upcomingDates = Object.keys(doctor.availability).slice(0, 6)

  return (
    <div className="page-container">
      <div className={styles.header}>
        <img src={doctor.photo} alt={doctor.name} className={styles.photo} />
        <div>
          <h1 className={styles.name}>{doctor.name}</h1>
          <p className={styles.specialty}>{doctor.specialty}</p>
          <div className={styles.metaRow}>
            <Rating value={doctor.rating} reviews={128} />
            <span className={styles.dot}>&middot;</span>
            <span>{doctor.experience}+ yrs experience</span>
            <span className={styles.dot}>&middot;</span>
            <span>{doctor.location}</span>
          </div>
          <p className={styles.bio}>{doctor.bio}</p>
          <div className={styles.actionsRow}>
            <span className={styles.fee}>Consultation fee: ₹{doctor.fee}</span>
            <Button onClick={() => navigate(`/book/${doctor.id}`)}>Book Appointment</Button>
          </div>
        </div>
      </div>

      <div className={styles.availabilitySection}>
        <h2 className={styles.sectionTitle}>Upcoming Availability</h2>
        <div className={styles.dateGrid}>
          {upcomingDates.map((date) => (
            <div key={date} className={styles.dateCard}>
              <p className={styles.dateLabel}>
                {new Date(date).toLocaleDateString(undefined, {
                  weekday: 'short',
                  month: 'short',
                  day: 'numeric'
                })}
              </p>
              <p className={styles.slotCount}>
                {doctor.availability[date].length} slots open
              </p>
            </div>
          ))}
        </div>
        <Button variant="outline" onClick={() => navigate(`/book/${doctor.id}`)} style={{ marginTop: 16 }}>
          Choose a slot to book &rarr;
        </Button>
      </div>
    </div>
  )
}
