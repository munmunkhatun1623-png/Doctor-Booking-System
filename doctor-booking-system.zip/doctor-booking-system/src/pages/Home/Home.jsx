import { useState, useMemo } from 'react'
import { useFetch } from '../../hooks/useFetch.js'
import { fetchDoctors } from '../../api/doctorsApi.js'
import { specialties } from '../../data/doctors.js'
import DoctorCard from '../../components/DoctorCard/DoctorCard.jsx'
import SearchBar from '../../components/SearchBar/SearchBar.jsx'
import SpecialtyFilter from '../../components/SpecialtyFilter/SpecialtyFilter.jsx'
import Loader from '../../components/Loader/Loader.jsx'
import EmptyState from '../../components/EmptyState/EmptyState.jsx'
import styles from './Home.module.css'

export default function Home() {
  const [search, setSearch] = useState('')
  const [specialty, setSpecialty] = useState('')

  // Re-fetches from the (simulated) API whenever filters change,
  // demonstrating real API-integration data flow rather than pure
  // client-side filtering.
  const { data: doctors, loading, error } = useFetch(
    () => fetchDoctors({ search, specialty }),
    [search, specialty]
  )

  const resultCount = useMemo(() => doctors?.length ?? 0, [doctors])

  return (
    <div className="page-container">
      <h1 className="page-heading">Find & Book a Doctor</h1>
      <p className="page-subheading">Browse verified doctors and book an appointment in minutes.</p>

      <div className={styles.filters}>
        <div className={styles.searchWrap}>
          <SearchBar
            value={search}
            onChange={setSearch}
            placeholder="Search by doctor name or specialty..."
          />
        </div>
        <SpecialtyFilter specialties={specialties} value={specialty} onChange={setSpecialty} />
      </div>

      {loading && <Loader label="Fetching doctors..." />}

      {error && (
        <EmptyState title="Something went wrong" subtitle={error} />
      )}

      {!loading && !error && (
        <>
          <p className={styles.count}>{resultCount} doctor{resultCount !== 1 ? 's' : ''} found</p>
          {resultCount === 0 ? (
            <EmptyState
              title="No doctors match your search"
              subtitle="Try a different name, specialty, or clear your filters."
            />
          ) : (
            <div className={styles.grid}>
              {doctors.map((doc) => (
                <DoctorCard key={doc.id} doctor={doc} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}
