import { Link } from 'react-router-dom'
import Button from '../../components/Button/Button.jsx'

export default function NotFound() {
  return (
    <div className="page-container" style={{ textAlign: 'center', paddingTop: 80 }}>
      <h1 style={{ fontSize: '3rem', margin: 0 }}>404</h1>
      <p style={{ color: 'var(--color-text-muted)', marginBottom: 24 }}>
        The page you're looking for doesn't exist.
      </p>
      <Link to="/">
        <Button>Back to Home</Button>
      </Link>
    </div>
  )
}
