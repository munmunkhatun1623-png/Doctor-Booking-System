import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAppointments } from '../../context/AppointmentsContext.jsx'
import Loader from '../../components/Loader/Loader.jsx'
import Button from '../../components/Button/Button.jsx'
import EmptyState from '../../components/EmptyState/EmptyState.jsx'
import styles from './MyAppointments.module.css'

export default function MyAppointments() {
  const { appointments, loading, loadAppointments, removeAppointment } = useAppointments()

  useEffect(() => {
    loadAppointments()
  }, [loadAppointments])

  if (loading) return <Loader label="Loading your appointments..." />

  return (
    <div className="page-container">
      <h1 className="page-heading">My Appointments</h1>
      <p className="page-subheading">Manage your upcoming and past bookings.</p>

      {appointments.length === 0 ? (
        <EmptyState
          title="No appointments yet"
          subtitle="Book your first appointment to see it here."
          action={<Link to="/"><Button>Find a Doctor</Button></Link>}
        />
      ) : (
        <div className={styles.list}>
          {appointments.map((appt) => (
            <div key={appt.id} className={styles.card}>
              <div>
                <h3 className={styles.doctorName}>{appt.doctorName}</h3>
                <p className={styles.specialty}>{appt.specialty}</p>
                <p className={styles.dateTime}>
                  {new Date(appt.date).toLocaleDateString(undefined, {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric'
                  })}{' '}
                  at {appt.time}
                </p>
                <p className={styles.patient}>Patient: {appt.patient?.name}</p>
              </div>
              <div className={styles.rightCol}>
                <span
                  className={`badge ${appt.status === 'cancelled' ? 'badge-danger' : 'badge-success'}`}
                >
                  {appt.status === 'cancelled' ? 'Cancelled' : 'Confirmed'}
                </span>
                {appt.status !== 'cancelled' && (
                  <Button variant="danger" size="sm" onClick={() => removeAppointment(appt.id)}>
                    Cancel
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
