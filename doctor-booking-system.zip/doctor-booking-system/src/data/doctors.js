// Static seed data. Availability is generated per-doctor for the next 6 days
// so the app always has "fresh" dates relative to today, mimicking a live backend.

const SPECIALTIES = [
  'Cardiologist',
  'Dermatologist',
  'Pediatrician',
  'Neurologist',
  'Orthopedic',
  'Dentist',
  'ENT Specialist',
  'General Physician'
]

const TIME_SLOTS = [
  '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM',
  '11:00 AM', '11:30 AM', '02:00 PM', '02:30 PM',
  '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM'
]

function formatDate(d) {
  return d.toISOString().split('T')[0]
}

// Deterministic-ish pseudo-random so slot availability looks realistic
// but is stable within a single app load.
function seededPick(seed, arr, count) {
  const picked = []
  let s = seed
  for (let i = 0; i < arr.length && picked.length < count; i++) {
    s = (s * 9301 + 49297) % 233280
    if (s / 233280 > 0.35) picked.push(arr[i])
  }
  return picked.length ? picked : arr.slice(0, 3)
}

function buildAvailability(doctorSeed) {
  const availability = {}
  const today = new Date()
  for (let i = 0; i < 6; i++) {
    const d = new Date(today)
    d.setDate(today.getDate() + i)
    const key = formatDate(d)
    availability[key] = seededPick(doctorSeed + i, TIME_SLOTS, 12)
  }
  return availability
}

const RAW = [
  { name: 'Dr. Ananya Sharma', specialty: SPECIALTIES[0], experience: 12, fee: 900, rating: 4.8, location: 'Salt Lake, Kolkata', img: 4 },
  { name: 'Dr. Rohan Mehta', specialty: SPECIALTIES[1], experience: 8, fee: 700, rating: 4.6, location: 'Park Street, Kolkata', img: 12 },
  { name: 'Dr. Priya Nair', specialty: SPECIALTIES[2], experience: 15, fee: 600, rating: 4.9, location: 'Ballygunge, Kolkata', img: 5 },
  { name: 'Dr. Arjun Kapoor', specialty: SPECIALTIES[3], experience: 20, fee: 1500, rating: 4.7, location: 'New Town, Kolkata', img: 13 },
  { name: 'Dr. Kavita Iyer', specialty: SPECIALTIES[4], experience: 10, fee: 1000, rating: 4.5, location: 'Howrah', img: 9 },
  { name: 'Dr. Simran Kaur', specialty: SPECIALTIES[5], experience: 6, fee: 500, rating: 4.4, location: 'Behala, Kolkata', img: 20 },
  { name: 'Dr. Vikram Rao', specialty: SPECIALTIES[6], experience: 14, fee: 800, rating: 4.6, location: 'Dum Dum, Kolkata', img: 15 },
  { name: 'Dr. Meera Joshi', specialty: SPECIALTIES[7], experience: 9, fee: 500, rating: 4.3, location: 'Garia, Kolkata', img: 47 },
  { name: 'Dr. Sameer Khan', specialty: SPECIALTIES[0], experience: 18, fee: 1200, rating: 4.9, location: 'Alipore, Kolkata', img: 33 },
  { name: 'Dr. Neha Gupta', specialty: SPECIALTIES[2], experience: 11, fee: 650, rating: 4.7, location: 'Jadavpur, Kolkata', img: 25 }
]

export const doctors = RAW.map((doc, idx) => ({
  id: `doc-${idx + 1}`,
  ...doc,
  photo: `https://i.pravatar.cc/300?img=${doc.img}`,
  bio: `${doc.name} is a highly experienced ${doc.specialty.toLowerCase()} with ${doc.experience}+ years of practice, dedicated to patient-first, evidence-based care.`,
  availability: buildAvailability(idx + 1)
}))

export const specialties = SPECIALTIES
